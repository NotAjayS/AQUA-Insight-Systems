  const container = document.getElementById("particles-container");
  const welcome = document.getElementById("welcomeText");
  const dock = document.getElementById("dockPanel");

  // Step 1: Fade welcome after 1.5s
  setTimeout(() => {
    welcome.classList.add("fade-out");
  }, 1500);

  // Step 2: Hide welcome + show particles
  setTimeout(() => {
    welcome.style.display = "none";

    for (let i = 0; i < 50; i++) {
      const dot = document.createElement("div");
      dot.className = "particle";
      const size = Math.random() * 6 + 4;
      dot.style.width = `${size}px`;
      dot.style.height = `${size}px`;
      dot.style.left = `${Math.random() * 100}%`;
      dot.style.top = `${Math.random() * 100}%`;
      dot.style.animationDelay = `${Math.random() * 2 + 0.8}s`;
      container.appendChild(dot);
    }

    // Show sidebar after particle effect starts
    dock.style.display = "flex";
  }, 2200);

  // Step 3: Start MyDashBoard animation AFTER particles
  setTimeout(() => {
    const text = document.querySelector('.animated-text');
    if (text) {
      const str = text.textContent;
      text.innerHTML = '';
      str.split('').forEach((char, i) => {
        const span = document.createElement('span');
        span.textContent = char;
        span.style.animationDelay = `${i * 0.05}s`;
        text.appendChild(span);
      });
    }
  }, 2600);

document.addEventListener("DOMContentLoaded", function () {
  const container = document.getElementById("particles-container");
  const welcome = document.getElementById("welcomeText");
  const dock = document.getElementById("dockPanel");
  const title = document.getElementById("dashboardTitle");

  if (!container || !welcome || !dock || !title) {
    console.error("One or more required elements are missing.");
    return;
  }

  // Step 1: Fade out welcome text
  setTimeout(() => {
    welcome.classList.add("fade-out");
  }, 1500);

  // Step 2: Remove welcome, show particles + dock
  setTimeout(() => {
    welcome.style.display = "none";

    for (let i = 0; i < 50; i++) {
      const dot = document.createElement("div");
      dot.className = "particle";
      const size = Math.random() * 6 + 4;
      dot.style.width = `${size}px`;
      dot.style.height = `${size}px`;
      dot.style.left = `${Math.random() * 100}%`;
      dot.style.top = `${Math.random() * 100}%`;
      dot.style.animationDelay = `${Math.random() * 2 + 0.8}s`;
      container.appendChild(dot);
    }

    dock.style.display = "flex";
  }, 2200);

  // Step 3: Animate "My Dashboard"
  setTimeout(() => {
    const str = title.textContent.trim();
    title.innerHTML = '';
    title.style.opacity = '1';

    str.split('').forEach((char, i) => {
      const span = document.createElement('span');
      span.textContent = char;
      span.style.animationDelay = `${i * 0.05}s`;
      title.appendChild(span);
    });
  }, 2600);
});



document.addEventListener("DOMContentLoaded", () => {
  const title = document.getElementById("dashboardTitle");

  // Wait for intro animation to finish
  setTimeout(() => {
    const text = title.textContent.trim();
    title.innerHTML = ''; // Clear the text

    // Split text into spans with delay
    text.split('').forEach((char, i) => {
      const span = document.createElement('span');
      span.textContent = char;
      span.style.animationDelay = `${i * 0.05}s`;
      title.appendChild(span);
    });

    title.style.opacity = '1'; // Make it visible

    // Move to top after all letters have appeared
    setTimeout(() => {
      title.classList.add("move-to-top");
    }, text.length * 50 + 400); // Adjust timing if needed

  }, 2600); // Wait for intro animation to complete
});



window.addEventListener('load', () => {
  // Wait 3.5s to simulate dashboard animation finishing
  setTimeout(() => {
    const about = document.getElementById('aboutText');
    about.classList.remove('hidden');
    about.classList.add('show');
  }, 3500);
});



window.addEventListener("DOMContentLoaded", () => {
  const dashboardAnim = document.getElementById("myDashboard");
  const aboutText = document.getElementById("aboutText");

  // Wait for 3 seconds before switching content
  setTimeout(() => {
    dashboardAnim.style.display = "none";        // Hide the animation
    aboutText.classList.remove("hidden");        // Show the about section
  }, 3000); // adjust time (in ms) to match your animation duration
});

window.onload = function () {
  setTimeout(() => {
    document.getElementById("myDashboard").style.display = "none";
    document.getElementById("aboutText").style.display = "block";
  }, 3000); // Wait 3 seconds
};


window.onload = function () {
  setTimeout(() => {
    // Hide the MyDashboard animation
    document.getElementById("myDashboard").style.display = "none";

    // Show the about text immediately
    document.getElementById("aboutText").classList.remove("hidden");
  }, 5000); // Wait for 5 seconds before switching
};

